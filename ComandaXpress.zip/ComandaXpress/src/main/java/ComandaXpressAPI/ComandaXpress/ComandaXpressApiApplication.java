package ComandaXpressAPI.ComandaXpress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComandaXpressApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComandaXpressApiApplication.class, args);
	}

}
