package ComandaXpress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComandaXpressApplicationTests {

	@Test
	void contextLoads() {
	}

}
