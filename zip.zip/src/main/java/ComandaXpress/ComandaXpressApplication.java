package ComandaXpress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComandaXpressApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComandaXpressApplication.class, args);
	}

}
